def FlagsForFile( filename ):
  return {
    'flags': ['-x', 'c++'],
    'do_cache': True
  }
